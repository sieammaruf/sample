<html>
    <head>
        <title> Character Frequency Counter </title>
    </head>
    
    <body style="background-color:#D6EAF8;">
        <br><br>
        <hr>
        <h1 align="center" style ="color:#02768F"> Character Frequency Counter </h1>
        <hr>
        
        <h3 align="center">Insert your string into the following text area to get the count per character</h3>
        
        <br>
        
        <form align="center" action ="show.php" method="POST">
            
            <textarea class="scrollabletextbox" rows="8" cols="90" name="sentString"></textarea>
            
            <br>
            
            <button type="submit" align="center">Count</button>
            <button type="reset" align="center" value="reset">Clear</button>
            
        </form>
        
    </body>
</html>